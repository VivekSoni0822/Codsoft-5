import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

class Question {
    private String questionText;
    private List<String> options;
    private int correctOption;

    public Question(String questionText, List<String> options, int correctOption) {
        this.questionText = questionText;
        this.options = options;
        this.correctOption = correctOption;
    }

    public String getQuestionText() {
        return questionText;
    }

    public List<String> getOptions() {
        return options;
    }

    public int getCorrectOption() {
        return correctOption;
    }
}

class Quiz {
    private List<Question> questions;
    private int currentQuestionIndex;
    private int score;
    private List<Boolean> answers;

    public Quiz() {
        this.questions = new ArrayList<>();
        this.currentQuestionIndex = 0;
        this.score = 0;
        this.answers = new ArrayList<>();
    }

    public void addQuestion(Question question) {
        questions.add(question);
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        for (currentQuestionIndex = 0; currentQuestionIndex < questions.size(); currentQuestionIndex++) {
            Question currentQuestion = questions.get(currentQuestionIndex);
            System.out.println(currentQuestion.getQuestionText());
            List<String> options = currentQuestion.getOptions();
            for (int i = 0; i < options.size(); i++) {
                System.out.println((i + 1) + ". " + options.get(i));
            }

            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    System.out.println("\nTime's up!");
                    answers.add(false);
                    displayNextQuestion();
                }
            }, 10000); // 10 seconds timer

            System.out.print("Your answer (1-" + options.size() + "): ");
            int userAnswer = scanner.nextInt();
            timer.cancel();

            if (userAnswer - 1 == currentQuestion.getCorrectOption()) {
                score++;
                answers.add(true);
            } else {
                answers.add(false);
            }

            displayNextQuestion();
        }
        displayResults();
    }

    private void displayNextQuestion() {
        if (currentQuestionIndex + 1 < questions.size()) {
            System.out.println("\nNext question:");
        } else {
            displayResults();
        }
    }

    private void displayResults() {
        System.out.println("\nQuiz finished!");
        System.out.println("Your score: " + score + "/" + questions.size());
        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            System.out.println((i + 1) + ". " + question.getQuestionText());
            System.out.println("Correct answer: " + question.getOptions().get(question.getCorrectOption()));
            System.out.println("Your answer: " + (answers.get(i) ? "Correct" : "Incorrect"));
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Quiz quiz = new Quiz();
        List<String> options1 = List.of("Option A", "Option B", "Option C", "Option D");
        List<String> options2 = List.of("Option 1", "Option 2", "Option 3", "Option 4");

        quiz.addQuestion(new Question("Question 1?", options1, 1));
        quiz.addQuestion(new Question("Question 2?", options2, 2));

        quiz.start();
    }
}
